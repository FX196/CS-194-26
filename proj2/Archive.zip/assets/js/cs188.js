$(function () {
    let div = $('#forward-checking-fail-eg');
    $('#show-forward-checking-fail-eg').click(function () {
        div.fadeToggle(1000);
    });
});

$(function () {
    let div = $('#entailment-eg');
    $('#show-entailment-eg').click(function () {
        div.fadeToggle(1000);
    });
});

$(function () {
    let div = $('#bayes-factor-eg');
    $('#show-bayes-factor-eg').click(function () {
        div.fadeToggle(1000);
    });
});