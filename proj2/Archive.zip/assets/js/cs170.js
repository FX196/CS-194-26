$(function () {
    let div = $('#dual-eg');
    $('#show-eg').click(function () {
        div.fadeToggle(1000);
    });
});

$(function () {
    let div = $('#memory-bound-proof');
    $('#show-memory-bound-proof').click(function () {
        div.fadeToggle(1000);
    });
});