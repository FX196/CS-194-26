I used a jupyter notebook for all my code except for the alignment helper functions. Just use the run all function for the results.
